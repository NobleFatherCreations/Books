# The Sacred Divide — editing pass, 31 of 34 volumes

Completed: language pass (fragments, glosses, loops, grade rationales, proofing, removal of "edition/version" narration) plus fact-check.
Not yet done: new-age, unification-church, indigenous.

- volumes/        the edited volume text (Markdown), one per tradition
- edits/          every wording change as a reversible entry (before/after/reason/status); _all.json applies to every volume
- fact-check/     claim-by-claim results with source links
- discrepancies/  suspected factual errors per volume (P1 = serious, P2, P3). Text was NOT changed for these; they await your decision
- proposals/      suggested expansions per volume
- wording-log/    human-readable log of each wording change
- docs/           P1-REGISTER.md (all P1 items in one list), DISCREPANCIES.md (incl. the two help-line corrections applied), TEMPLATE-FIXES.md, and cross-volume analysis
