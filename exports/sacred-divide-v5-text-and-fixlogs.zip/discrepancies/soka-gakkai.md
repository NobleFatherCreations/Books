Status 2026-10-03: fixes applied, see soka-gakkai-FIXLOG.md (deferred items remain open).

# DISCREPANCIES — Soka Gakkai, awaiting the owner's decision

Format: **[Location]** what is wrong → proposed wording → why it matters. Nothing below has been changed in the text; every item touches the frozen layer (numbers, dates, grades, source entries), moves loop text, or would soften a claim the wording pass may not weaken.
Evidence is in `logs/fact-check/soka-gakkai.md` (F-numbers). Omissions are in `docs/sacred-divide-v5/proposals/soka-gakkai.md`.

## P1 · Critical

1. **[§5 timeline 1999 and "Moments" 2025; §6 table; §10 card 1 "Expired?"; §22 Japan; narration "law"]** "Twenty-six years in government", "Twenty-six years in power end", "in government with the LDP 1999–2025", "A party in national government for 26 years" → proposed: "Twenty-six years in a governing coalition (about 23 of them in government; Komeito was in opposition 2009–12)" → Komeito sat in opposition from 2009 to 2012. The 26 years count the LDP–Komeito cooperation (Nippon.com), not continuous government. A hostile reader will test this first (F4). Not softened in the text.
2. **[§7 "Who holds what", Komeito row]** "Party leadership (Tetsuo Saito, 2025)" and the page's silence on 2026 → proposed: add that Komeito merged its lower-house members into the Centrist Reform Alliance in January 2026, that the Alliance disbanded in September 2026, and that Komeito is an opposition party under a new leader (Mitsunari Okamoto, appointed at a convention the week of 30 Sept 2026) → The page reads as if the 2025 exit were the latest development, and "Saito" is no longer the leader (F5). Dated "2025" so not false, but stale.
3. **[§16 "Who pays"]** "Households strained by contributions [8]" (the editor's note "(needs a stronger source)" has been removed from the text) → proposed: either cite a primary or scholarly source, or delete the line → Source 8 is a Wikipedia reference summary, and §9 itself says current contribution practice "is not established from a primary source". The claim has no supporting source (F20).
4. **[§5 history 1930]** "founded … as a lay group within Nichiren Shoshu" → proposed: "founded in 1930 as the Soka Kyoiku Gakkai, an educators' society, and later aligned with Nichiren Shoshu" → The founding sources describe an education reform society; the lay-body relationship with the priesthood is not shown for 1930 (F9). Not softened in the text.
5. **[§3 "The strongest objection" Concede line; §6 source 10; §5 timeline 1995]** "The French report was contested and led to a defamation complaint against its chair [10]" → proposed: "The 1999 French report led to a defamation complaint against the commission president, Jacques Guyard, who was discharged in 2001 on the ground of good faith" → The complaint followed the 1999 report, not the 1995 report listed in the timeline (F14). The page also does not establish Soka Gakkai's presence on the 1995 list (F13); the secondary source names it in 1999.

## P2 · Should fix

6. **[§22 UK "tell"]** "Outside Japan, the movement is a small charity with no political party." → proposed: "Outside Japan, the movement is organized as national bodies, often registered charities, and has no political party." → "A small charity" does not describe about 3 million members in 192 countries and territories (F21).
7. **[§22 Japan "tell"]** "described by the ruling party as aimed at Soka Gakkai" → proposed: "described by an LDP spokesman as aimed at Soka Gakkai" → One spokesman said it (F12); §8 states it correctly.
8. **[§1–§7 membership]** The figures are 2021 data (press release of 18 Nov 2021) shown without a date. → proposed: add "(2021 announcement)" to §1 and §7 → Readers will take them as current (F1).
9. **[§9, §1 *Seikyo Shimbun* 5.5 million]** The claim dates from 1997 per the cited summary. → proposed: "claimed 5.5 million in 1997" if the 1997 date is confirmed from a primary source → The circulation is stated as present-day (F15).
10. **[§13 loops]** Loop 2 ("Fear: Weak.") had no content. The card now says only what the page records and rates the loop weak. A loop with this little support may not belong in a list of seven. Also, loop text was not moved between cards.
11. **[§12 table vs cards]** §12 is a table, not cards: there is no per-technique grade rationale ("Evidence grade" note) to rewrite and no `#t-n` anchors. Loop technique links point to `#techniques`. Decide whether this volume should be rebuilt in the card format used by the finished volumes.
12. **[§12 grade basis]** Grades that the row's own content does not obviously support: **22 Benevolent control, Taught** (the row describes district leaders' practice, not teaching; points to Cultural); **5 Devaluation, Taught** (the row describes practice; the doctrine of human revolution is taught, so Taught may hold); **3 Future faking, Taught** (same); **12 DARVO, Contested** and **17 Smear campaign, Contested** (both rest on the 1969–70 affair, which §19 tags ACADEMIC SOURCE; Documented may fit); **7 Double bind, 10 Strategic ambiguity, 30 Plausible deniability, Documented** (all rest on the separation policy against scholarship [5]; consistent). No grade was changed.
13. **[§15 "How the cost is denied"]** Levels are asserted with no note for five channels: Doctrinal ambiguity Low, Cultural outsourcing Low, Volunteer enforcement High, Sacred secrecy Medium, Exit cost denial Low. Nothing in the volume supports "Volunteer enforcement High" or "Sacred secrecy Medium". → proposed: add a sourced note to each or remove the unsupported levels.
14. **[§21 Voices from inside]** Only Makiguchi is from inside the tradition. The 1995-law opponents and McLaughlin are outsiders. → proposed: add former members' or insiders' published accounts (see proposals) or retitle the section.
15. **[§19]** Neither case is a court record (the 1970 incident is ACADEMIC SOURCE; the French report is GOVERNMENT REPORT — contested). The generic narration said the cases "carry a court, regulator or inquiry record"; the narration was corrected (SOK-P edit) but the section remains thin.
16. **[§26 source 5]** The note "Cite page numbers at import" was removed from the text. No page numbers are given for McLaughlin, so the many [5] citations (electoral mobilization, newspaper sales, Women's Division) point to a whole book. → proposed: add page numbers.
17. **[§22 Japan "regulator"]** "The Agency for Cultural Affairs" is cited to [11], which discusses "central government"; the Agency is not confirmed there.
18. **[§1 glance, §7 "Mentor" row]** "Vacant since Nov 2023" is not sourced (F7).

## P3 · Style and consistency

19. **[Spelling]** The volume mixes British and American spelling: British "practising" (§4), "centres" (§9, §13); American "organization", "labor", "centered", "recognized". Recorded, not normalized.
20. **[§7 "Religious Corporations Law" vs §8 "Religious Corporations Act"]** One statute, two names. Source 11 uses "Law".
21. **[§1, §3, §23 "Who decides which candidate is kosen-rufu?"]** The question is glossed at first use in the glance cell only. The wording is otherwise unchanged in §3.
22. **[§14 "Predict"]** "will be settled administratively, without a member vote" is an unsourced prediction.
23. **[§14 "Chair now"]** "The president and the executive" names an "executive" the volume never defines.
24. **[§7 trend, §11 Bodies]** "aging in Japan; growth in some countries abroad" and "Top leadership has historically been male" have no citation.
25. **[§4 last bullet]** "In many countries, a light-touch, voluntary practice" has no citation.
26. **[§12 Hook, §14 Words]** "Human revolution" is glossed at first use in §12 and again in §14; the §7 title *The Human Revolution* is a book.
27. **[§12 defense and counter cells]** Quoted defenses were left unchanged as quotations. Several counters remain questions or imperatives ("Then let the doubt stand.").
28. **[§12 stage "Isolate"]** The cell reads as a note to the editor ("Weak compared with other pages in this book"). It now states the same point as a sentence.
29. **[§8, §20]** "Who can compel an answer" and "What would change this page" are the page's only statements of what would change it; both are one-line lists.
30. **[Narration q3 "why"]** "why the organization chooses not to have it verified" asserts a choice the page does not document.
31. **[Source notes 8 and 10]** They say claims resting on these reference summaries "are stated cautiously on this page". The claims in §5 (F9), §3 (F14) and §16 (F20) are not stated cautiously.
32. **[§25 help lines]** Faith to Faithless and Recovering from Religion print no hours (Faith to Faithless: "set hours, see website"; actual: Wed 10:00–13:00, Thu 16:00–19:00, Fri 08:00–11:00; Recovering from Religion: aims at 24-hour service, no firm hotline hours). ICSA prints no number ("Via website"). Both numbers are correct. Shared data; not edited.
33. **Template checks.** No "rabbinic", tithe cards, fee ladders, "Dera", "attributed to God", "ashram" or Zen/Thai-apex content found. §9 has no pipeline cards, so none to assess. Stage 8 ("Replace") and technique 30 do not name any divine authority. Build markers removed: "(record as a relative strength)" in a §15 table cell, "*(needs a stronger source)*" in §16, "**Cite page numbers at import.**" in source 5. None of "(lede: …)", "To add:", "Not confirmed", "research lead" or "Take income figures …" appears.
